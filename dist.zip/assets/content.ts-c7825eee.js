import{a as u}from"./axios-4a70c6fc.js";const g=()=>{const e=document.createElement("img");e.src="https://img.icons8.com/?size=512&id=108653&format=png",e.id="floatingIconButton",e.alt="icon button",e.style.cursor="pointer",e.style.position="absolute",e.style.width="50px",e.style.height="50px",e.style.top="40px",e.style.right="10px",e.style.zIndex="99999999999",document.body.appendChild(e)},x=()=>{const e=document.createElement("div");e.id="myExtensionModal",e.style.position="fixed",e.style.top="50%",e.style.left="50%",e.style.transform="translate(-50%, -50%)",e.style.backgroundColor="#dadada",e.style.borderRadius="5px",e.style.boxShadow="0 4px 8px rgba(0, 0, 0, 0.1)",e.style.zIndex="9999999999",e.style.display="none",e.innerHTML=h,document.body.appendChild(e)},h=`
<div style="position: relative; width: 380px">
      <button id="modalCloseBtn" style="position: absolute; top: 5px; right: 5px;">X</button>
      <div style="display: flex; flex-direction: column;  gap: 7px; padding: 20px">

        <h1 style="text-align: center; margin-bottom: 10px">Webhook Notifier</h1>
        <label for="webhookUrl">Webhook URL:</label>
        <input  style="padding: 3px 7px; font-size: 18px; font-weight: 600" type="text" id="webhookUrl" />

        <label for="mobileNumber">Mobile:</label>
        <input style="padding: 3px 7px; font-size: 18px; font-weight: 600" type="text" id="mobileNumber" />

        <label for="sendType">Type:</label>
        <input style="padding: 3px 7px; font-size: 18px; font-weight: 600" type="text" id="sendType" placeholder="text OR media" />

        <label for="mediaUrl">Attachments url:</label>
        <input style="padding: 3px 7px; font-size: 18px; font-weight: 600" type="text" id="mediaUrl" />

        <label for="messageContent">Content:</label>
        <textarea style="padding: 3px 7px; font-size: 18px; font-weight: 600" id="messageContent" rows="7"></textarea>

        <button id="submitBtn" style="padding: 3px 7px; font-size: 18px; font-weight: 600">Submit</button>
    
      </div>
    </div>
`;console.clear();const f=()=>{g(),x();let e,l;chrome.storage.sync.get(["selectedText","webHookURL","mobileNumber"]).then(t=>{e=t==null?void 0:t.webHookURL,l=t==null?void 0:t.mobileNumber});const a=document.getElementById("myExtensionModal");document.getElementById("floatingIconButton").addEventListener("click",()=>{chrome.storage.sync.get(["selectedText","webHookURL","mobileNumber"]).then(t=>{e=t==null?void 0:t.webHookURL,l=t==null?void 0:t.mobileNumber}),a.style.display="block",setTimeout(()=>{const t=document.getElementById("modalCloseBtn"),o=document.getElementById("webhookUrl"),n=document.getElementById("mobileNumber"),d=document.getElementById("sendType"),y=document.getElementById("mediaUrl"),m=document.getElementById("messageContent"),c=document.getElementById("submitBtn");o.value=e??"",n.value=l??"",c==null||c.addEventListener("click",async b=>{if(b.preventDefault(),!o||!n||!d||!m)return alert("fill the required input form!");if(d.value.toLowerCase()==="text"){const i={action:"send-message",type:"text",content:m.value,phone:n.value};console.log(i);try{await u.post(`${o.value}`,i),chrome.storage.sync.set({webHookURL:o.value}),r()}catch(p){alert("Fail to send message"),console.log("err",p)}}else if(d.value.toLowerCase()==="media"){const i={action:"send-message",type:"media",content:m.value,attachments:[`${y}`],phone:n.value};try{await u.post(`${o.value}`,i),chrome.storage.sync.set({webHookURL:o.value}),r()}catch{alert("Error to send message")}}else alert("Invalid type!")});const r=()=>{a.style.display="none"};t==null||t.addEventListener("click",r)},1e3)})},w=()=>{chrome.runtime.onMessage.addListener((e,l,a)=>{a("success!"),e.message==="tabPathChanged"&&setTimeout(()=>{var t,o;const s=document.getElementById("subvalue_MOBILE");if(s){const n=(o=(t=s.innerText)==null?void 0:t.trim().replace(/[^0-9]/g,""))==null?void 0:o.trim();chrome.storage.sync.set({mobileNumber:n})}},2e3)})};document.readyState==="complete"&&(w(),f());
