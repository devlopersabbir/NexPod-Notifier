export type TSendType = "text" | "media";
